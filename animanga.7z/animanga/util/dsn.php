<?php

// Data source name

 return [

    "dbname"    => "animanga",
    "host"      => "localhost",
    "user"      => "root",
    "password"  => "toor",
];
