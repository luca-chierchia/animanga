<?php
echo "sono la pagina errorPage.php";