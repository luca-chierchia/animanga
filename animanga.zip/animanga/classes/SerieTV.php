<?php

class SerieTV extends MediaItem
{

}