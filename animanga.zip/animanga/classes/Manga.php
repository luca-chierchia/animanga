<?php

class Manga extends MediaItem
{
    private array $vol;

}