<?php

echo "ciao sono il read.php";
