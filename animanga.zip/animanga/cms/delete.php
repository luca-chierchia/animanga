<?php
echo "ciao sono delete.php";
